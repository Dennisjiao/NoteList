#include <stdio.h>
#include <stdlib.h>

int main()
{   int n,a[n],i,j,max,min;
    printf("Input n: ");
    scanf("%d",&n);
    printf("Input %d integers: ",n);
    for(i=0;i<n;i++)
    {
        scanf("%d",a[i]);
    }
    //swap
    max=a[0];
    for(i=0;i<n;i++)
    {
        if(max<a[i])
    }
    for(i=0;i<n;i++)
    {
       printf("After swapped: %d",a[i]);
    }

    return 0;
}
